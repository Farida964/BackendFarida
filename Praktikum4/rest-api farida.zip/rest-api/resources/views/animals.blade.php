<?php
class Animal {
    public $animals = [];

    public function __construct($data)
    {
        $this->animals = $data;
    }


}


?>